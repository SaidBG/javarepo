package main;
import java.util.Scanner;
import static java.lang.System.*;

public class Corrig� {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		if (a!=0) {
			
			int b = 3+2*a;
			out.println("b="+b);
			
			
		}
		else {
			a=8;
			
			int c=3+a;
			out.println("c="+c);
			
			
						
		}
		out.println("a="+  a);
		
		
	}

}
