package main;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int f = 0;
		int f1 = 1;
		int stock = 0;
		for(int i = 0 ; i < 10; i++ ) {
			
		}
		
		
		
		
	}

}
