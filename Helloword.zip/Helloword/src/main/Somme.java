package main;

public class Somme {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 0;
		int b = 0;
		for(a=0; a <= 100; a++) {
			b+=a;
			System.out.println(b);
			
		}

	}

}
